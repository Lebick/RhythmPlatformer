using System.Linq;
using System.Collections.Generic;
using UnityEngine;

public class TrackEditor : MonoBehaviour
{
    public RectTransform contentRect;

    private readonly Vector2 offset = new(-610, -100);

    public List<RectTransform> tracks;

    public GameObject notePrefab;

    private int magneticValue = 25;

    private RectTransform test;

    private void Start()
    {

    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            SelectCheck();
        }

        Vector2 mousePos = Camera.main.ScreenToViewportPoint(Input.mousePosition);
        mousePos = new Vector2(mousePos.x * 1920, mousePos.y * 1080 - 540);

        test.offsetMax = new(-contentRect.anchoredPosition.x + mousePos.x + offset.x / 2 - 100, test.offsetMax.y);
    }

    private void SelectCheck()
    {
        CreateNote();
    }

    private void CreateNote()
    {
        Vector2 mousePos = Camera.main.ScreenToViewportPoint(Input.mousePosition);
        mousePos = new Vector2(mousePos.x * 1920, mousePos.y * 1080 - 540);

        int myTrack = tracks.IndexOf(tracks.OrderBy(a => Mathf.Abs((a.anchoredPosition.y + offset.y) - mousePos.y)).First());

        int xPos = (int)(-contentRect.anchoredPosition.x + mousePos.x + offset.x/2);

        xPos = GetMagneticPos(xPos);
        

        GameObject newNote = Instantiate(notePrefab, tracks[myTrack]);
        RectTransform noteRect = newNote.GetComponent<RectTransform>();

        test = noteRect;

        noteRect.offsetMin = new(0 + xPos, noteRect.offsetMin.y);
        noteRect.offsetMax = new(-50 + xPos, noteRect.offsetMax.y);
    }

    private int GetMagneticPos(int value)
    {
        string newPos = value.ToString();
        int lastTwoIndex = int.Parse(newPos[^2..]);

        List<int> values = new();
        for (int i = 0; i <= 100; i += magneticValue)
        {
            if (magneticValue <= 0) break;

            values.Add(i);
        }

        int nearestValue = values.OrderBy(a => Mathf.Abs(a - lastTwoIndex)).First();

        if (nearestValue == 100)
            newPos = (int.Parse(newPos) + 100).ToString();

        string finalPos = $"{newPos[..^2]}{nearestValue.ToString("D2")[^2..]}";

        print(nearestValue.ToString("D2")[^2..]);
        return int.Parse(finalPos);
    }

    public void OnClickMagneticBtn(int value)
    {
        magneticValue = 200 / value;
    }
}
